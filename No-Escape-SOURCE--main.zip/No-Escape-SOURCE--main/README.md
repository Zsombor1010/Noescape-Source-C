# No-Escape-(SOURCE)

CREDITS: Leurak, Enderman, AND MANY MORE PEOPLE I USED killwindowsinstant which was used in memz because i was either lazy


# CHECK out THE video : https://www.youtube.com/watch?v=g43r7D0I8HU
# (completed everything this EXEFILE might work) and the source code is the "source" but it won't work properly when compiled
# pls set to "release", "x86" when compiling
# the creator is not responsible for any damage done using this so HoPe YoU uNdErStAnD
